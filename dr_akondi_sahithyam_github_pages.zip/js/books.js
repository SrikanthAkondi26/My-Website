// Front-end demonstration. Replace this with Supabase/API loading after backend setup.
const books = [
  // {title:'Book title', year:'2026', description:'Description', cover:'files/cover.jpg', pdf:'files/book.pdf'}
];
const container=document.getElementById('books');
if(container && books.length){container.innerHTML=books.map(b=>`<div class="card"><img src="${b.cover||''}" alt="" style="width:100%;max-height:260px;object-fit:cover"><h2>${b.title}</h2><p>${b.description||''}</p><p>${b.year||''}</p><a class="btn" href="${b.pdf}" target="_blank">Download Book</a></div>`).join('');}