# Dr. AKondi Sahithyam — Viswajyothi

This is a static GitHub Pages starter website.

## Important
GitHub Pages is excellent for the public website, but it is **not a secure backend**. A real admin login, book upload, photo upload and database should use a backend such as Supabase.

## Planned production architecture
- GitHub Pages: free public website
- Supabase Auth: secure Admin login
- Supabase Storage: PDF books and gallery photos
- Supabase Database: book/photo metadata
- Frontend JavaScript: displays published books/photos

## Deployment
Create a public repository named `YOURUSERNAME.github.io`, upload all files, then enable GitHub Pages from Settings → Pages → Deploy from branch → main → root.

Replace placeholder content and the portrait placeholder with approved content/photo.
